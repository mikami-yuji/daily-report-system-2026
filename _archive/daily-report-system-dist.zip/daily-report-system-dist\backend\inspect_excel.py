import openpyxl
import os

files = [f for f in os.listdir('..') if f.endswith('.xlsm')]
print(f"Found xlsm files in ..: {files}")

for f in files:
    try:
        wb = openpyxl.load_workbook(os.path.join('..', f), read_only=True, keep_vba=True)
        print(f"File: {f}")
        print(f"Sheets: {wb.sheetnames}")
    except Exception as e:
        print(f"Error reading {f}: {e}")
