from main import get_customers
import sys

try:
    print("Imported main.")
    filename = "daily_report_template.xlsm"
    print(f"Calling get_customers('{filename}')...")
    # We call get_cached_dataframe directly to inspect types, or inspect result
    from main import get_cached_dataframe
    df = get_cached_dataframe(filename, '得意先_List')
    print("DataFrame Types:")
    print(df.dtypes)
    
    # Check for any timestamps in object columns
    for col in df.columns:
        if df[col].dtype == 'object':
            first_val = df[col].dropna().iloc[0] if not df[col].dropna().empty else None
            if first_val:
                print(f"Column {col} sample value type: {type(first_val)}")

    print(f"Calling get_customers('{filename}')...")
    
    # ... (existing code for dtype inspection) ...

    result = get_customers(filename)
    print(f"Success! Got {len(result)} records.")
    
    import json
    print("Testing JSON serialization...")
    try:
        json_str = json.dumps(result)
        print("JSON serialization successful.")
    except Exception as e:
        print(f"JSON serialization FAILED: {e}")
        # Find the culprit
        for i, record in enumerate(result):
            try:
                json.dumps(record)
            except:
                print(f"Record {i} failed serialization: {record}")
                break
except Exception as e:
    import traceback
    traceback.print_exc()
    print(f"Error: {e}")
