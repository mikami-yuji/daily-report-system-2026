# 社内PC用セットアップスクリプト
# 実行すると、バックエンドの設定ファイル(config.json)を自動作成し、
# アプリケーションを起動します。

Write-Host "社内PC用セットアップを開始します..." -ForegroundColor Cyan

# バックエンドディレクトリへ移動
$BackendDir = Join-Path $PSScriptRoot "backend"
if (!(Test-Path $BackendDir)) {
    Write-Error "backendディレクトリが見つかりません。プロジェクトルートで実行してください。"
    exit 1
}

# config.jsonの内容（社内ネットワークパスを設定）
$ConfigContent = @{
    excel_dir = "\\Asahipack02\社内書類ｎｅｗ\01：部署別　営業部\02：営業日報\2025年度"
}

# JSONファイル作成（UTF-8 BOMなし）
$JsonPath = Join-Path $BackendDir "config.json"
$JsonString = ConvertTo-Json $ConfigContent -Compress
[System.IO.File]::WriteAllText($JsonPath, $JsonString, (New-Object System.Text.UTF8Encoding $false))

Write-Host "設定ファイル(config.json)を作成しました。" -ForegroundColor Green
Write-Host "設定パス: $($ConfigContent.excel_dir)" -ForegroundColor Gray

# ネットワークパスのアクセス確認
if (Test-Path $ConfigContent.excel_dir) {
    Write-Host "ネットワークパスへのアクセスを確認しました: OK" -ForegroundColor Green
} else {
    Write-Host "警告: ネットワークパスにアクセスできません。" -ForegroundColor Yellow
    Write-Host "VPNに接続しているか、社内ネットワークに繋がっているか確認してください。" -ForegroundColor Yellow
    Write-Host "VPNに接続しているか、社内ネットワークに繋がっているか確認してください。" -ForegroundColor Yellow
}

# 依存関係のインストール
Write-Host "`n必要なライブラリをインストールしています..." -ForegroundColor Cyan

# Backend (Python)
Write-Host "Backend (Python) のライブラリを確認中..." -ForegroundColor Gray
try {
    Push-Location $BackendDir
    if (Get-Command "py" -ErrorAction SilentlyContinue) {
        py -m pip install -r requirements.txt
    } elseif (Get-Command "python" -ErrorAction SilentlyContinue) {
        python -m pip install -r requirements.txt
    } else {
        Write-Warning "Pythonが見つかりません。Pythonがインストールされているか確認してください。"
    }
    Pop-Location
} catch {
    Write-Warning "Pythonライブラリのインストールに失敗しました。"
}

# Frontend (Node.js)
Write-Host "Frontend (Node.js) のライブラリを確認中..." -ForegroundColor Gray
$FrontendDir = Join-Path $PSScriptRoot "frontend"
if (Test-Path $FrontendDir) {
    try {
        Push-Location $FrontendDir
        if (Get-Command "npm" -ErrorAction SilentlyContinue) {
            npm install
        } else {
            Write-Warning "npm (Node.js) が見つかりません。Node.jsがインストールされているか確認してください。"
        }
        Pop-Location
    } catch {
        Write-Warning "Node.jsライブラリのインストールに失敗しました。"
    }
} else {
    Write-Warning "frontendディレクトリが見つかりません。"
}

Write-Host "`nアプリケーションを起動します..." -ForegroundColor Cyan

# start_app.batを実行
$StartScript = Join-Path $PSScriptRoot "start_app.bat"
if (Test-Path $StartScript) {
    Start-Process $StartScript
} else {
    Write-Error "start_app.batが見つかりません。"
}
